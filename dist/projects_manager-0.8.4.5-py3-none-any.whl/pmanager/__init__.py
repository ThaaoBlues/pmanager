#because it can't be empty on github

__version__ = "0.8.4.5"